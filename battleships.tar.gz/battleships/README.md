requires node:^4.2.3

npm install
npm test
npm start

OR for debug:
node run_game.js -d
